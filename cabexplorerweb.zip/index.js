// JavaScript Document
/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
$(document).ready(function() {
    $(".dropdown-toggle").dropdown();
});